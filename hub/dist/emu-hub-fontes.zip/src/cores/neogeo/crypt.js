/* Tabelas do chip CMC42 (kof99_*) e CMC50 (kof2000_*) e do M1 (m1_*). Geradas a partir do MAME (BSD-3-Clause, S. Smith / David Haywood / Razoola e outros). */
const NG_CMC_TABLES = {
  kof99_type0_t03: 'fb869df1bf80d543abb39f6a33d9dbb666086988ccb7de4997641fa6c02f5242445af2289887968a830b036171996bb51a8efe04e1f77dddedca37fcef3972dab8beee7fe53178f3919ad21119b9094cfd6d2a4d65a189c7755021fa1600e912742b1e4f1401703a4e3ff5f41d3d1527a7ff45e06ef954c848ada50af62d2ce26867d685b4c334bc62d35f84065b0d95ea5e9ed4eb907a058157e8602e20257c460c93cbbd177eec79b2c22241b110aca8bb9b824b9c8b07473524568dafe6264038c45d1bc5d10f6c7bb0e3a3236f58c1bacfd7a2e7d0635cf873a013dc29cdc976ae8fe45930aa941c3c0e55927732c6ce1836dfa98cd8a4f03b514a023e53',
  kof99_type0_t12: '1fac4dcdca70026b184062b23f9b5bef6968713bcbd430bc4772745e844c1bdb6a351df5a1b3875d57282fc4fd242636adbe616373aa82ee29d0df8c15b596f3dd7e3a37587f0cfc0b07e8f7f414b881b6d71ec885e69d3360c595d55500a3b77d500dd2c112e5edd8a49c8f2a4fa801528365ea9a6c444ae2a52b46e13425f8c3dac76e48387c7806536416983c914239ccb0f1eb13bb0532860ea20a9efa66548ed3e7192077ecffbd6d432303ab753dcfd1de9231a7454bc297f97a88d91ce9e410c9222d9076177904511a5a5f2c216f3ee0f0bfd6940f8011a05ca9492eceafa69f7b99b9b4e3fbf627f293fe0867ae0989dc4ec6c08ab1598b41568dba',
  kof99_type1_t03: 'a917af0d346e53b67f58e9145f55dbd442809959a83a575dd56f4c683546a6e77b71e093a21f6421e3b19826abadeee5bbd91e2e9536ef23794504ed131df48596ecc232aa7c15d8da92909db7566a6641fc00f65024cffb11fe82489b271b674e8469976d8cd2ba74f98fa5545ccd7307d10109f1193b5e873076ccc05aa74922fa1602dfa4ffb37533bd882fcb2a44b8bf1c0f811043b4c87e9a25ea834b387ad73d1a4f6251c9470ece3fc74d2ca186b9c5cadd6b706c919cbe0a9ff594bc182b602029f7f228c4a00b65de8d78123ed077088bae05313cd6a38906dc5272b0b537d3c38ac6f0c161fd4a5b7d9ef363402de8b2e63903eb8ee10ce4e2f8ac',
  kof99_type1_t12: 'eae65ea78eac34033097525376f2620b0afc94b8673611bcaecafa15042b17c43e5b590157e2bab7d13ff06a9c2acba9e32cc00f46918ad098c5a61b9629120963ede0a28677bee565dbbd50b39d1a4e790c0043df3d54338f89a87bf9d52782bbc28c47886bb4c3f8aa061e837d057885f66e2eec5a31453814168b02e44fb0bfaba49e4860193508dedd669051cca3af709b7595496c64727e44a0732568551f407a740e8ddc1c71c8cfd7e8ceeb323aee07614dfe5c7c562f2d5f6f9f8122584baddab9101823e1f36de7e928d6d8f44c3921b284c12426f19337c64acd20c9d9c7b1ff99d45db5a1870d69921380d2d3fd1df53ba57fef9ab642fb3cf741',
  kof99_address_8_15_xor1: '00b11ec53d40455ef2f80463368788bfabcc7808dd20d435098e44ae33a99ecdb3e5ad41dabef416572e5367afdb8ad834173c015573cfe3e8c70de9a3130cf6904efb976d5fa87111fcd19581ba8c1b39fea215a6524d5b59a5e096d98f7bed29d31f0eec230fb86c6f7d1846d6e4b59a7902f503c060665c2f76859d541a6a28ce7f7c91994c833eb41d05c1c3d747debc626e86148077ebf3073156d2c2c66bdcfd2292f006512d38e6a025dfd52c1c94129cb09bc40bc8d0f730cb27fa7a1061aaa470b72a5ac9f10a4965ee694b3a8d325d68b99f75193fac374fe793897e4a3bea747243bd24efb6ff6458848ba7bbb2e1262b50ca21f998a1e2428248',
  kof99_address_8_15_xor2: '9b9dc13da9b8f46ff625c747d597df6beb90a4b25df566b0b98b9364ec7b658cf143426e459fb335067196dba0fb0b3a1ff88e69cd26ab86a20cbd63a57ae76a5f189ebfad55b11c5c0330c63720e3c952e8ee4f0170c477292aba5312047daf338fa84daa5bb40f92bbede12f506cd22c95d9f998c3764cf2e4e52bef9c49b6313bbca1cade6274ea8100dda646883f39d62354244ad8dcd7d1ccbe577cda4461ced3d4e92880e0568a09059a891bf7f3996d5e4891c0d0c579784159212effc24b388332e6e27f1e17581d1afa858294c8727eb7ac0efcfd1627758dcb08fe0a020d3611228440343e2d685aa767ae8707106014733c5119a3b5cf13f0154e',
  kof99_address_16_23_xor1: '005f0352cee37d8f6bf820de7b7e39bef594187880c97f7a3e63f2e04ef78727696ca41d855be644250c98c70102a3260938dbc31ecf23456876d6225d5aae169fa2b5cd81ea5eb8b99d9c1a0fffe1e774aad4affcc633295cab95f019475967f396601f6292bd89ee281306fefa326d573c54502c5849fb17ccefb2b4f90770c5a9dfd53b862b0d6e4d0a904331c1f6880bda5314dc758eb0eb9946a11571c8e93f4ad973e57c3077d3b34b3772c204970836b13a61ece21c9a8bd11b2e9e8ad841e4c4402fadc0b6845166bb12e8ddcbbc6fd01183564ccabf0510d7bafded8c0e4f3d3591b7ac34642af1796a9b2d65f442a08da74855219324d2a6a5a882',
  kof99_address_16_23_xor2: '29971a2c0b943e75010d1be14d38398fe7d06090b20fbb701fe65b87b443fdf5f6f9adc098179f91155155646c18610ed993abd6242f6a3a22b14faa2348edb9888ba36b264ce82d1c99bd5c580850f22a62c172660410376efc44a9dfd420ddee41db73de54ecc9f34b2eae5a4a5e47072b76a4e328feb0f00206d1af42c2a5e067bf168e35ce8ae53d7b96d779521ea1fb9bbe219ce956147fa0e4c3c446eaf7d21d310a5feba2688db5c5740cdc8280091995719a1157774ec6ff1203a7c7f4c8b67a59363c53e2698c25054563f83489333f8527bc65faa86d845dba403230ef8313a678cc819edacad37e9d6fcdb7b3d8cf3b0092b886ac497cf1d5cb7d',
  kof99_address_0_7_xor: '74ad5d1d9ec3fa4ef7dbcaa26436560c4fcf43661e91e3a558c2c1d4b9dd7616ce6175012b22385550ef6c9905e9e8e02da44b4a42aeba8c6f9314bd7121b00215c4e660d744fd857e788f0081f1a73ba010f49f39883562cb19311151fb2a2045d37d921bf2090d97a9b53cee5caf7bd23a498eb6cdd9de8a296ed80be169871a9618ccdfe7c5c7f852c9f0b7e533da679da3030e722679e2b8fcaafeb486c8d1bc120877eb408d04254d5a6a7a2e41651c1394b26328595e9a3007c6bf17f50f89f31fea6db3c07047f953f6d654ed6b4ce48b832490b17cbb73abd52f5fec9c2ca834463727a10a068068823284ff48ac7f3f95dc989bbe23573e5bd03da6',
  kof2000_type0_t03: '1061f178855268e3120dfaf0c9365e3df9a6012ec784ea2b6d14384f551c9da77ac6f89ae642b5ed7d3ab105434a22fdaca431c33276959e7e888ea29718be2af5d6cacc723b876cde75d721cb0bdde7e165aab944fb66151a3c98cf8adf37a52f67d283b66bfce0b47c08dc9330abe419c28beba00ac803c04b6471869c9b1679ff70098cd0f6530773d489b300e9feec8fbcb21e5d1135a906599fc1d37bf2c5774e3920d56a82da45f3338123bae21d5f5c5149ae8dc4a8f71f0f3428a1d927d84c2cbf913e695741250c5a9092b0636f40af74b82d80bb4694e529eeb71b96ad130e5899604d1726cee8dbef24a36e7f543f02d15b505648f4bd624704cd',
  kof2000_type0_t12: 'f428b48ffaeb8e542b49d17671478b5792857cb85c22f926bc5b6d67ae5f6ff59f4866400d114eb26b35150f18251dbad36979eca88cc97f4bdb51afcae2b381125e7e38c89501fffdfbf2746214a598a6da8053e856ac1b52d0f14542b61a4a3a99fcd29ccf312ddd862f29e10319a241338390c1bf0b083dd88d6c39a0e355025046e6c382361375ab27d71f0ad489594fc05dc6f788bd3c00efcd051caa9bed7a611793fe23b9f36878f65a7be0e4a3ee1672c73b8a372a70a92c21f82409ce209e0687c50464437d4d10d6a4944c60dedf58b1443fb0d9e5cbbbbeea0734736a77f09d0c2e0e919accc2b76397d5dcc432e7843e30a11eb56e65e9ada796',
  kof2000_type1_t03: '9a2fcc4e4069accaa57b0a61910d5574cd8b0b80095e38c7dabff537233133e9ae87e5fa6e5cadf476629f2e01e2f6478c7caa98b59251ec5f075d6f16a11da94845f06a9c1e11a00646d5f173ed94f7c3571be097b1a4a724e72b055b340cb80f9bc84d5aa6863e1429845890db2d549d82d47dc6674189c113b09e816da859bd398ee6258fd9a2e453c5727e364a4f52c2222ace3c212c00d7758a27ee43fecb6bb9a378b7850220d083c412f9fdd879643a4903b4c0f2df15930835ff70dd286c0e04de7a65d2ab4295e13f3b7f66d18de3bb1cfc771a881819681f56d6e8b6bcd3ea3d26b3c944dcf33230ef964caf17f8fb6050eb4b9963bab271cf10be',
  kof2000_type1_t12: 'daa7d66e2f5ef03fa4ced3fd462aacc9beeb9fd53c619611d038ca06ed1b65e723ddd905bf5b5da59500ecf101a9a6fcbb54e32e92580a7bb6ccb15f143572ffe652d78cf343af9cc04f0c428eef80cd1d7e883b98a1ade49d8d2b56b550df666dd46009e1ee4a47f9fe730789a839ea829ecf26b24ec359f23d9ab069f7bc34e53622fb5771996c833055c2bdf477e97697a0e0b9866ba384671a70025a415c2581aa28784bc66453164d8b2093ae0f942c3ac762e8c4db04c5fa2948d108240de2d810b4918a130edcd279b8f8ba2dcbf57d37514031a20b18637fb3ab9b87f690dec827457c1c856833190375157a1f498f4cc14417126f32b73e741e216a',
  kof2000_address_8_15_xor1: 'fc9b1c357253d67d84a4c5937be747d524a2fa190cb18cb99dd8594f3cb2784a2a969af11f22a85b67a30f00fbdfeb0a57b825d7f06b0b3195232d5c27c7f4551af774bed3ac3dc17fbd280110e509371e58af17f21630923668e6d4eab775547741b48de0f35103a9e866ab29a5edcbd1aaf5db4c42978aaec96e043385dd2b6fef12217aa15a91c8ccc0a7603e562fe47199c2a0458065bb87698173caf64643da267e8fe18bfd5079bac6634bb38e34e24814cde3c4051340066c88b0e91b4df876024494cf32fece3b5d2c895fdcd29c6aec186d0e86ff5e9eee11d049524e61900dc3391583b5623f707cad20bf2e081df9b6a664078238983a9fdebcd9',
  kof2000_address_8_15_xor2: '00be065afa4215f23f0a84934e783b893298a28773dd26e50571086e9be0df9efc8381efb2c0c3bfa76d1b95edb93e13b0479c7a244168d0360bb5c267f754921e44862b94ccba230dca6b4c2a9a2d8be35229f021bdbb1fa3abf846b745825edb075de99d1a48ce9112d4eea939f1182c228a7e344a8cc114f32035d99633779f767c90c6d5a15bac75c70cb317d69956a63d1db12ed8bc2fde60556c40cd43ffad387951c80e5fc466cba87da43aea277b708e5c190f806f8f10f94985697feb1c016537a528e46a0304d1311130fb8897d3f6c54df53ce861dcd2b4b8a0ae16250209fecf5363af59f4e1ecd7e750e2c9aa4b8d4fe664da74b6725762fd58',
  kof2000_address_16_23_xor1: '459f6e2f28bc5e6ddab50db8c08ea232eecd8d488c2714eb65d7f293999091fc5fcbfa753f26de723339c71f887973ab4e365d44d241a07ea78ba6bf03d886dc2caa703d460780580b2be2f0b1fe42f3e9a38578c3d05adb1afb9d8aa5120e548fc56cae255b4b17029c4a2440e59e22c64962b66bbba8cce8815047c8be5ca4d6944f7b9acfe4597aa1ea3137132daf2169191d6f16981e08e3b24d9b7fa977edbdd4d934d3ca091860c96a01f4f664b43a15ac89526871e782c10c92f730e61c3e0f0a6735ba61dd29c2f89795b73be0cef9d50676b3054c04843c8723637c5356e17d961bd1ec2a66f11110ff432edf8374f53820fdadc4b95551b0ef0057',
  kof2000_address_16_23_xor2: '00b8f034ca213cf9018e7570ec132796f45b881feb4a7d9dbe0214afa206c6db356b74457b29d2feb615d08aa92d19f65e5a90e91133c247374c4f59c304571df2636d6e3195cb3e67b2e398ed8de6fbf8ba5dd42af53b82051644ef4de793da9fbb61c953bd767852360c66c110dd7a8469cdfd580d6c8968ad3ab04b46c503b4f7308c4e6073a18bb162ccd108fc777ecf565107a68092dc0ba4c7e8e1b571eab32f9418e23d4965aaf191c899557986a726a0ac5fce6a5cf3878f121cd8e49b642e1ed7c017bca3a89a0e25404150b9bf28df32549e48d52b42fa9c7fd38543de810f24c438ae831b6f7ce5ff1ad93fb7229709e0a520232c72d639ab0aee',
  kof2000_address_0_7_xor: '2648069b21a91b76c9f8b467e4ff99f7159e6200724da04f02f1eaef0bf3eba693786f7cdad47b05e9c6d6db50ced201b5e8e02a081ab8e3f9b1f48b392d859c557363403896dca3a2a125666d568e100f311cf528770ad17534a4fe7d0751794190223512bbc4cab21fcbc8acddd00dfcc59d14bc83d958c2309a6ac00cadf65d747f2fbd1d47d5e689cfb7d3593698f0fb3cf23fa71882425cabbade520991aa61ecd79523cd80a568602771e12c2e8d2b5765bfc119c74964884acc204ed83b4c135f9fbe5e6efde2fa54370e167a6c33b370847ec304b0aeb9810329df46e569e724925a4b5b94113a3d87ed97b6323e45af1e43448c53866beea88a8f17',
  m1_address_8_15_xor: '0a72b7af67de1db178c44fb54b1876dd11e236a1820398a0105f3fd61f906a0b70e064cb9f388b5304caf8d007685632ae1c2e4863929a9c4485414009c0c8bfeabbf72d9921f6ba15ceabb02a60bcf1f09ed597d84e149d424d2c5c2ba6e1a7ef25337aebe71b6d4c522662b635be8001bdfd37f9475571b4f2ff27fa23c9831739130dc78616ec496ffe34058f00e6a4da7bc1f3f4d975286687a8456c20e977937e3c1e74f58c3e94d4c25a060ee83da9b2e3e422cf248e6b8a8d844ad291887957a50fcdb9ac3baab3d1ee31817cd789d39643c5c6c3697f46df305b6ee508959bfbb8580c61505d3aa22912fc517d1a0265545e19ccdcdb73edad592fa3',
  m1_address_0_7_xor: 'f4bc02f72c3de8d95062ecbd537379610034cfa2632890af443bc58d3a46077066bed88be9a04b98dcdfe21674f137f5b72181011c1b943609a14a9130929b9a29b1384d55f2561824479d3f801f22a41154840d2548eec65915037afd6cc3335bc47b5a057fa640a95d418a9652d3f0ab7210886f957ca8cd9c5f32ae8539ace5d7fbd4082319656ba793bb2bbfb835d00626683eddb9692ab2de874558ff3c9e7ddaed498c148e752fe06e786d20d2fa2d51ccc7e71d2797fc31dbf842e3995e830eb42ef6c00c4c57b6640a17a3c17712fee68f1371e4f9ad9fced5897e0fc286f367ba6043c904b3b01eb5c8eba576ea5c821a4faacae10b4ecb6aefd1d6',
};

/* Descriptografia dos cartuchos do Neo Geo (portada do MAME): chips CMC42/CMC50 (gráficos) e SMA (ROM de programa do Metal Slug 3). */
const NeoCrypt = (() => {
  const hex = s => { const o = new Uint8Array(256); for (let i = 0; i < 256; i++) o[i] = parseInt(s.substr(i * 2, 2), 16); return o; };
  const T = fam => { const p = fam === 'cmc50' ? 'kof2000_' : 'kof99_', g = n => hex(NG_CMC_TABLES[p + n]);
    return { t0t03: g('type0_t03'), t0t12: g('type0_t12'), t1t03: g('type1_t03'), t1t12: g('type1_t12'), a815x1: g('address_8_15_xor1'), a815x2: g('address_8_15_xor2'), a1623x1: g('address_16_23_xor1'), a1623x2: g('address_16_23_xor2'), a07x: g('address_0_7_xor') }; };
  /* bitswap estilo MAME: os argumentos dizem de qual bit de entrada vem cada bit de saída, do mais alto para o mais baixo */
  const bs = (v, bits) => { let r = 0; const n = bits.length; for (let i = 0; i < n; i++) r |= ((v >> bits[i]) & 1) << (n - 1 - i); return r; };
  /* rom: C1/C2 intercalados byte a byte (como no MAME). Devolve {c1, c2} descriptografados. */
  function gfxDecrypt(rom, size, extra, fam) {
    const t = T(fam), n = size >> 2, buf = new Uint8Array(size);
    for (let rpos = 0; rpos < n; rpos++) {
      const hi = (rpos >> 8) & 0xFF, tmp0 = t.t1t03[(rpos & 0xFF) ^ t.a07x[hi]];
      let x0 = (t.t0t03[hi] & 0xFE) | (tmp0 & 1), x1 = (tmp0 & 0xFE) | (t.t0t12[hi] & 1);
      const o = rpos << 2;
      if ((rpos >> 8) & 1) { buf[o] = rom[o + 3] ^ x0; buf[o + 3] = rom[o] ^ x1; } else { buf[o] = rom[o] ^ x0; buf[o + 3] = rom[o + 3] ^ x1; }
      const tmp1 = t.t1t12[(rpos & 0xFF) ^ t.a07x[hi]];
      x0 = (t.t0t12[hi] & 0xFE) | (tmp1 & 1); x1 = (tmp1 & 0xFE) | (t.t0t03[hi] & 1);
      if (((rpos >> 16) ^ t.a1623x2[hi]) & 1) { buf[o + 1] = rom[o + 2] ^ x0; buf[o + 2] = rom[o + 1] ^ x1; } else { buf[o + 1] = rom[o + 1] ^ x0; buf[o + 2] = rom[o + 2] ^ x1; }
    }
    const c1 = new Uint8Array(size >> 1), c2 = new Uint8Array(size >> 1);
    for (let rpos = 0; rpos < n; rpos++) {
      let b = rpos ^ extra;
      b ^= t.a815x1[(b >> 16) & 0xFF] << 8; b ^= t.a815x2[b & 0xFF] << 8;
      b ^= t.a1623x1[b & 0xFF] << 16; b ^= t.a1623x2[(b >> 8) & 0xFF] << 16; b ^= t.a07x[(b >> 8) & 0xFF];
      if (size === 0x3000000) { if (rpos < 0x800000) b &= 0x7FFFFF; else b = 0x800000 + (b & 0x3FFFFF); }
      else if (size === 0x6000000) { if (rpos < 0x1000000) b &= 0xFFFFFF; else b = 0x1000000 + (b & 0x3FFFFF); }
      else b &= n - 1;
      const s = b << 2, d = rpos << 1;
      c1[d] = buf[s]; c2[d] = buf[s + 1]; c1[d + 1] = buf[s + 2]; c2[d + 1] = buf[s + 3];
    }
    return { c1, c2 };
  }
  /* a camada fixa (S) vem do fim da ROM de gráficos já descriptografada */
  function sfix(c1, c2, size, fixSize) {
    const out = new Uint8Array(fixSize), base = size - fixSize;
    for (let i = 0; i < fixSize; i++) { const j = base + (i & ~0x1F) + ((i & 7) << 2) + ((~i & 8) >> 2) + ((i & 0x10) >> 4); out[i] = (j & 1 ? c2 : c1)[j >> 1]; }
    return out;
  }
  /* chip SMA (KOF99, Garou, Metal Slug 3, KOF 2000): portado de prot_sma.cpp do MAME (BSD-3-Clause, S. Smith, David Haywood, Fabio Priuli, Razoola, Mr.K).
     Cada jogo: dados = troca de linhas de dados; fix = origem+bits do trecho fixo (0xC0000 bytes); bank = bloco, bits e limite do trecho com banco; order = ordem das duas etapas;
     sel = bits que desembaralham o número do banco; tab = deslocamentos do banco; w/rng = endereços do registrador de banco e do gerador aleatório. */
  const T64 = (...v) => v;
  const SMA = {
    kof99: { gfx: 'cmc42', key: 0x00, fixSize: 0x20000, fixBank: 0, w: 0x2FFFF0, rng: [0x2FFFF8, 0x2FFFFA],
      data: [13, 7, 3, 0, 9, 4, 5, 6, 1, 12, 8, 14, 10, 11, 2, 15], fixSrc: 0x700000, fix: [18, 11, 6, 14, 17, 16, 5, 8, 10, 12, 0, 4, 3, 2, 7, 9, 15, 13, 1],
      blk: 0x800, bank: [6, 2, 4, 9, 8, 3, 1, 7, 0, 5], lim: 0x600000, bankFirst: true, sel: [5, 12, 10, 8, 6, 14],
      tab: T64(0x000000, 0x100000, 0x200000, 0x300000, 0x3cc000, 0x4cc000, 0x3f2000, 0x4f2000, 0x407800, 0x507800, 0x40d000, 0x50d000, 0x417800, 0x517800, 0x420800, 0x520800,
        0x424800, 0x524800, 0x429000, 0x529000, 0x42e800, 0x52e800, 0x431800, 0x531800, 0x54d000, 0x551000, 0x567000, 0x592800, 0x588800, 0x581800, 0x599800, 0x594800, 0x598000) },
    garou: { gfx: 'cmc42', key: 0x06, fixSize: 0x80000, fixBank: 1, w: 0x2FFFC0, rng: [0x2FFFCC, 0x2FFFF0],
      data: [13, 12, 14, 10, 8, 2, 3, 1, 5, 9, 11, 4, 15, 0, 6, 7], fixSrc: 0x710000, fix: [18, 4, 5, 16, 14, 7, 9, 6, 13, 17, 15, 3, 1, 2, 12, 11, 8, 10, 0],
      blk: 0x8000, bank: [9, 4, 8, 3, 13, 6, 2, 7, 0, 12, 1, 11, 10, 5], lim: 0x800000, bankFirst: false, sel: [12, 14, 6, 7, 9, 5],
      tab: T64(0x000000, 0x100000, 0x200000, 0x300000, 0x280000, 0x380000, 0x2d0000, 0x3d0000, 0x2f0000, 0x3f0000, 0x400000, 0x500000, 0x420000, 0x520000, 0x440000, 0x540000,
        0x498000, 0x598000, 0x4a0000, 0x5a0000, 0x4a8000, 0x5a8000, 0x4b0000, 0x5b0000, 0x4b8000, 0x5b8000, 0x4c0000, 0x5c0000, 0x4c8000, 0x5c8000, 0x4d0000, 0x5d0000,
        0x458000, 0x558000, 0x460000, 0x560000, 0x468000, 0x568000, 0x470000, 0x570000, 0x478000, 0x578000, 0x480000, 0x580000, 0x488000, 0x588000, 0x490000, 0x590000,
        0x5d0000, 0x5d8000, 0x5e0000, 0x5e8000, 0x5f0000, 0x5f8000, 0x600000) },
    garouh: { gfx: 'cmc42', key: 0x06, fixSize: 0x80000, fixBank: 1, w: 0x2FFFC0, rng: [0x2FFFCC, 0x2FFFF0],
      data: [14, 5, 1, 11, 7, 4, 10, 15, 3, 12, 8, 13, 0, 2, 9, 6], fixSrc: 0x7f8000, fix: [18, 5, 16, 11, 2, 6, 7, 17, 3, 12, 8, 14, 4, 0, 9, 1, 10, 15, 13],
      blk: 0x8000, bank: [12, 8, 1, 7, 11, 3, 13, 10, 6, 9, 5, 4, 0, 2], lim: 0x800000, bankFirst: false, sel: [13, 11, 2, 14, 8, 4],
      tab: T64(0x000000, 0x100000, 0x200000, 0x300000, 0x280000, 0x380000, 0x2d0000, 0x3d0000, 0x2c8000, 0x3c8000, 0x400000, 0x500000, 0x420000, 0x520000, 0x440000, 0x540000,
        0x598000, 0x698000, 0x5a0000, 0x6a0000, 0x5a8000, 0x6a8000, 0x5b0000, 0x6b0000, 0x5b8000, 0x6b8000, 0x5c0000, 0x6c0000, 0x5c8000, 0x6c8000, 0x5d0000, 0x6d0000,
        0x458000, 0x558000, 0x460000, 0x560000, 0x468000, 0x568000, 0x470000, 0x570000, 0x478000, 0x578000, 0x480000, 0x580000, 0x488000, 0x588000, 0x490000, 0x590000,
        0x5d8000, 0x6d8000, 0x5e0000, 0x6e0000, 0x5e8000, 0x6e8000, 0x6e8000, 0x000000) },
    mslug3: { gfx: 'cmc42', key: 0xad, fixSize: 0x80000, fixBank: 1, w: 0x2FFFE4, rng: [0x2FFFF8, 0x2FFFFA],
      data: [4, 11, 14, 3, 1, 13, 0, 7, 2, 8, 12, 15, 10, 9, 5, 6], fixSrc: 0x5d0000, fix: [18, 15, 2, 1, 13, 3, 0, 9, 6, 16, 4, 11, 5, 7, 12, 17, 14, 10, 8],
      blk: 0x10000, bank: [2, 11, 0, 14, 6, 4, 13, 8, 9, 3, 10, 7, 5, 12, 1], lim: 0x800000, bankFirst: false, sel: [9, 3, 6, 15, 12, 14],
      tab: T64(0x000000, 0x020000, 0x040000, 0x060000, 0x070000, 0x090000, 0x0b0000, 0x0d0000, 0x0e0000, 0x0f0000, 0x120000, 0x130000, 0x140000, 0x150000, 0x180000, 0x190000,
        0x1a0000, 0x1b0000, 0x1e0000, 0x1f0000, 0x200000, 0x210000, 0x240000, 0x250000, 0x260000, 0x270000, 0x2a0000, 0x2b0000, 0x2c0000, 0x2d0000, 0x300000, 0x310000,
        0x320000, 0x330000, 0x360000, 0x370000, 0x380000, 0x390000, 0x3c0000, 0x3d0000, 0x400000, 0x410000, 0x440000, 0x450000, 0x460000, 0x470000, 0x4a0000, 0x4b0000, 0x4c0000) },
    mslug3a: { gfx: 'cmc42', key: 0xad, fixSize: 0x80000, fixBank: 1, w: 0x2FFFE4, rng: [0x2FFFF8, 0x2FFFFA],
      data: [2, 11, 12, 14, 9, 3, 1, 4, 13, 7, 6, 8, 10, 15, 0, 5], fixSrc: 0x5d0000, fix: [18, 1, 16, 14, 7, 17, 5, 8, 4, 15, 6, 3, 2, 0, 13, 10, 12, 9, 11],
      blk: 0x10000, bank: [12, 0, 11, 3, 4, 13, 6, 8, 14, 7, 5, 2, 10, 9, 1], lim: 0x800000, bankFirst: false, sel: [11, 12, 6, 1, 3, 15],
      tab: T64(0x000000, 0x030000, 0x040000, 0x070000, 0x080000, 0x0a0000, 0x0c0000, 0x0e0000, 0x0f0000, 0x100000, 0x130000, 0x140000, 0x150000, 0x160000, 0x190000, 0x1a0000,
        0x1B0000, 0x1C0000, 0x1F0000, 0x200000, 0x210000, 0x220000, 0x250000, 0x260000, 0x270000, 0x280000, 0x2B0000, 0x2C0000, 0x2D0000, 0x2E0000, 0x310000, 0x320000,
        0x330000, 0x340000, 0x370000, 0x380000, 0x390000, 0x3A0000, 0x3D0000, 0x3E0000, 0x400000, 0x410000, 0x440000, 0x450000, 0x460000, 0x470000, 0x4A0000, 0x4B0000, 0x4C0000) },
    kof2000: { gfx: 'cmc50', key: 0x00, fixSize: 0x20000, fixBank: 0, w: 0x2FFFEC, rng: [0x2FFFD8, 0x2FFFDA],
      data: [12, 8, 11, 3, 15, 14, 7, 0, 10, 13, 6, 5, 9, 2, 1, 4], fixSrc: 0x73a000, fix: [18, 8, 4, 15, 13, 3, 14, 16, 2, 6, 17, 7, 12, 10, 0, 5, 11, 1, 9],
      blk: 0x800, bank: [4, 1, 3, 8, 6, 2, 7, 0, 9, 5], lim: 0x63a000, bankFirst: true, sel: [5, 10, 3, 7, 14, 15],
      tab: T64(0x000000, 0x100000, 0x200000, 0x300000, 0x3f7800, 0x4f7800, 0x3ff800, 0x4ff800, 0x407800, 0x507800, 0x40f800, 0x50f800, 0x416800, 0x516800, 0x41d800, 0x51d800,
        0x424000, 0x524000, 0x523800, 0x623800, 0x526000, 0x626000, 0x528000, 0x628000, 0x52a000, 0x62a000, 0x52b800, 0x62b800, 0x52d000, 0x62d000, 0x52e800, 0x62e800,
        0x618000, 0x619000, 0x61a000, 0x61a800) },
  };
  const smaBank = (g, sel) => 0x100000 + (SMA[g].tab[bs(sel, SMA[g].sel)] || 0);
  /* rom = palavras de 16 bits da região inteira (0x900000 bytes), como o MAME as guarda depois do WORD_SWAP */
  function smaDecrypt(g, rom) {
    const c = SMA[g], B = 0x100000 / 2;
    for (let i = B; i < B + 0x800000 / 2; i++) rom[i] = bs(rom[i], c.data);
    const banked = () => { const n = c.blk / 2, buf = new Uint16Array(n); for (let i = 0; i < c.lim / 2; i += n) { buf.set(rom.subarray(B + i, B + i + n)); for (let j = 0; j < n; j++) rom[B + i + j] = buf[bs(j, c.bank)]; } };
    const fixed = () => { for (let i = 0; i < 0xC0000 / 2; i++) rom[i] = rom[c.fixSrc / 2 + bs(i, c.fix)]; };
    if (c.bankFirst) { banked(); fixed(); } else { fixed(); banked(); }
  }
  /* gerador aleatório do SMA (LFSR de 16 bits, começa em 0x2345) */
  const smaRng = st => { const o = st.v, n = ((o >> 2) ^ (o >> 3) ^ (o >> 5) ^ (o >> 6) ^ (o >> 7) ^ (o >> 11) ^ (o >> 12) ^ (o >> 15)) & 1; st.v = ((o << 1) | n) & 0xFFFF; return o; };
  /* M1 (Z80) criptografada do CMC50 (KOF 2000 e outros): a chave é a soma dos 64 KB iniciais */
  const P1 = [[15, 14, 10, 7, 1, 2, 3, 8, 0, 12, 11, 13, 6, 9, 5, 4], [7, 1, 8, 11, 15, 9, 2, 3, 5, 13, 4, 14, 10, 0, 6, 12], [8, 6, 14, 3, 10, 7, 15, 1, 4, 0, 2, 5, 13, 11, 12, 9], [2, 8, 15, 9, 3, 4, 11, 7, 13, 6, 0, 10, 1, 12, 14, 5],
    [1, 13, 6, 15, 14, 3, 8, 10, 9, 4, 7, 12, 5, 2, 0, 11], [11, 15, 3, 4, 7, 0, 9, 2, 6, 14, 12, 1, 8, 5, 10, 13], [10, 5, 13, 8, 6, 15, 1, 14, 11, 9, 3, 0, 12, 7, 4, 2], [9, 3, 7, 0, 2, 12, 4, 11, 14, 10, 5, 8, 15, 13, 1, 6]];
  function m1Decrypt(m) {
    const rom = new Uint8Array(0x80000); rom.set(m.subarray(0, 0x80000));
    const x815 = hex(NG_CMC_TABLES.m1_address_8_15_xor), x07 = hex(NG_CMC_TABLES.m1_address_0_7_xor);
    let sum = 0; for (let i = 0; i < 0x10000; i++) sum = (sum + rom[i]) & 0xFFFF;
    const kx = bs(sum, [12, 0, 2, 4, 8, 15, 7, 13, 10, 1, 3, 6, 11, 9, 14, 5]), out = new Uint8Array(0x80000);
    for (let i = 0; i < 0x80000; i++) {
      const blk = (i >> 16) & 7, p = P1[blk]; let a = (i & 0xFFFF) ^ kx;
      a = bs(a, [p[15], p[14], p[13], p[12], p[11], p[10], p[9], p[8], p[7], p[6], p[5], p[4], p[3], p[2], p[1], p[0]]);
      a ^= x07[(a >> 8) & 0xFF]; a ^= x815[a & 0xFF] << 8;
      a = bs(a, [7, 15, 14, 6, 5, 13, 12, 4, 11, 3, 10, 2, 9, 1, 8, 0]);
      out[i] = rom[(blk << 16) | a];
    }
    return out.subarray(0, Math.max(m.length, 0x10000));
  }
  return { gfxDecrypt, m1Decrypt, sfix, SMA, smaBank, smaDecrypt, smaRng, bs };
})();
if (typeof module !== 'undefined') module.exports = { NeoCrypt };
